#Library 
library(keras)
library(dplyr)
library(ggplot2)
library(purrr)

#Modifying the following parameters 
maxlen <- 150
training_samples <- 10000
validation_samples <- 10000
max_words <- 10000

#embedding_layer <- layer_embedding(input_dim = 1000,output_dim = 64)
#IMDB  dataset
data  <- dataset_imdb(num_words = max_words)
c(c(train_data,train_labels),c(test_data,test_labels)) %<-% data
#word_index <- dataset_imdb_word_index()

#pad_sequence is used to standardize the lengths
x_train <- pad_sequences(train_data,maxlen=150)
x_test <- pad_sequences(test_data,maxlen = 150)

#inspecting the length and review
length(x_train[1,])
x_train[1,]
length(x_train[2,])
x_train[2,]

#Split the data into train and validation sets

partial_x_train <- x_train[10001:nrow(x_train),]
x_val <- x_train[1:validation_samples,]

partial_y_train <- train_labels[10001:length(train_labels)]
y_val <- train_labels[1:validation_samples]

#build the model
model <- keras_model_sequential() %>% layer_embedding(input_dim = max_words, output_dim =8,input_length = maxlen) %>%
  layer_flatten() %>% 
  #layer_dense(units=16,activation = "relu") %>%
  layer_dense(units=1,activation = "sigmoid")
summary(model)

model %>% compile(optimizer="rmsprop",
                  loss ="binary_crossentropy",
                  metrics=c("acc")
)

#train the model
history <- model %>% fit(
  x_train,train_labels,epochs =10,batch_size=32,validation_data = list(x_val,y_val)
)
plot(history)

#Evaluate the model on test data 
results <- model %>% evaluate(x_test,test_labels)
results












